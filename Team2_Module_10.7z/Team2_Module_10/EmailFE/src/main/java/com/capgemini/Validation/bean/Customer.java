package com.capgemini.Validation.bean;

public class Customer {
	
	private int code;
	//private int id;
	private String username;
	private String password;
	private boolean status;
	private String email;
	
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	/*public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}*/
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Customer() {
		super();
	}
	
	//public Customer(int code, int id, String username, String password, boolean status, String email) {
	public Customer(int code, String username, String password, boolean status, String email) {
		super();
		this.code = code;
		//this.id = id;
		this.username = username;
		this.password = password;
		this.status = status;
		this.email = email;
	}
	
	
	

}
