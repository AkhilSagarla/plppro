package com.capgemini.Validation.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Validation.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService service;

	@RequestMapping("/sendemail")
	public String getProductById(@RequestParam String email) {
		try {
		service.find(email);
	
		}
		catch(MailException e) {
			System.out.println(e.getMessage());
			
		}
		return service.find(email);
	}

	@RequestMapping("/getvalidated")
	public void getEmailByStatus(@RequestParam String code) {
		service.getCustomer(Integer.parseInt(code));
		
	}
}
