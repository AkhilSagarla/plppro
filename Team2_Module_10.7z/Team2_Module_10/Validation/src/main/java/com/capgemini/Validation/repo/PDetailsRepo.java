package com.capgemini.Validation.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.Validation.bean.Customer;
import com.capgemini.Validation.bean.PDetails;

@Repository
public interface PDetailsRepo extends CrudRepository<PDetails, String>{

}
