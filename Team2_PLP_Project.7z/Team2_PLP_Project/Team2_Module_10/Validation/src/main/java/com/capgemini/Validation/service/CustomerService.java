package com.capgemini.Validation.service;

import java.util.Optional;

import com.capgemini.Validation.bean.Customer;

public interface CustomerService {


	public int getCustomer(int code);

	public String find(String email);
	
	
}
