package com.capg.bean;

public class Customer {
	private int code;
	
	private String email_id;
	private String userName;
	private String phonenumber;
	private String address;
	private String password;
	public Customer() {

	}
	public Customer(String email_id, String userName, String phonenumber, String address, String password) {
		super();
		
		this.email_id = email_id;
		this.userName = userName;
		this.phonenumber = phonenumber;
		this.address = address;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [email_id=" + email_id + ", userName=" + userName + ", phonenumber=" + phonenumber
				+ ", address=" + address + ", password=" + password + "]";
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
 
	public int getCode() {
		return code;
	}
	public void setCode() {
		code =(int)Math.random()*9999;
	}
}
