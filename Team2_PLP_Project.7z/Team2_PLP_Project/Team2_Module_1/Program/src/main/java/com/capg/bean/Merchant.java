package com.capg.bean;
public class Merchant {
	
	private int code;
	private String email_id;
    private String merchantName;
    private String phoneNumber;
	private String address;
    private String productType;
	private String password;
	public Merchant() {
		
	}
	@Override
	public String toString() {
		return "Merchant [email_id=" + email_id + ", merchantName=" + merchantName + ", phoneNumber=" + phoneNumber
				+ ", address=" + address + ", productType=" + productType + ", password=" + password + "]";
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Merchant(String email_id, String merchantName, String phoneNumber, String address, String productType,
			String password) {
		super();
		this.email_id = email_id;
		this.merchantName = merchantName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.productType = productType;
		this.password = password;
	}
	
	public int getCode() {
		return code;
	}
	public void setCode() {
		code =(int)Math.random()*9999;
	}

}
