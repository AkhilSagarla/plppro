package com.capg.service;

import java.util.Optional;

import org.springframework.mail.MailException;

import com.capg.bean.Customer;

public interface CustomerService {

	public void saveCustomer(String email_id, String password, String userName, String phonenumber, String address);

	public void Notification(Optional<Customer> customer) throws MailException;
	
	public Optional<Customer> getCustomer(String email);
}
