package com.capg.service;

public interface MerchantService {
	public void saveMerchant(String email_id, String password,String merchantName, String phoneNumber, String address, String product_type);

}
