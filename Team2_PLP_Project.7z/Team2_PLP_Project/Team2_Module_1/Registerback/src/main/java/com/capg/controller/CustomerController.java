package com.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capg.service.CustomerService;
import com.capg.service.MerchantService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService service;
	@Autowired
	MerchantService service1;

	@RequestMapping(value="/savecustomers{email_id}{password}{userName}{phonenumber}{address}")
	public void saveCustomer(@RequestParam String email_id,@RequestParam String password,@RequestParam String userName,@RequestParam String phonenumber,@RequestParam String address){
	service.saveCustomer(email_id,password,userName,phonenumber,address);	 
	System.out.println("Registered Successfully");
	
		 	 }
	
	@RequestMapping(value="/savemerchant{email_id}{password}{merchantName}{phoneNumber}{address}{producttype}")
	public void saveMerchant(@RequestParam String email_id,@RequestParam String password,@RequestParam String merchantName,@RequestParam String phoneNumber,@RequestParam String address,
			@RequestParam String productType){
	service1.saveMerchant(email_id,password,merchantName,phoneNumber,address,productType);	 
	System.out.println("Registered Successfully");
 }

}


	