package com.capg.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Customer;
import com.capg.service.CustomerService;

@RestController
public class EmailController {
 
	@Autowired
	private CustomerService service;
	@RequestMapping("/sendmail")
	public String sendmail(@RequestParam String email) {
		Optional<Customer> customer=service.getCustomer(email);
		try {
			service.Notification(customer);
		} catch (MailException e) {
			System.out.println(e.getMessage());
		}
		return "Email Sent";
	}
}
