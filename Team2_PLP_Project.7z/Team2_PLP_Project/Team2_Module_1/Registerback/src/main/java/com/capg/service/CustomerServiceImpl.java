package com.capg.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.capg.bean.Customer;
import com.capg.repo.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepo repo;

	private JavaMailSender javaMailSender;

	public CustomerServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	@Override
	public void saveCustomer(String email_id, String password, String userName, String phonenumber, String address) {
		Customer c = new Customer();

		c.setEmail_id(email_id);
		c.setPassword(password);
		c.setUserName(userName);
		c.setPhonenumber(phonenumber);
		c.setAddress(address);
		repo.save(c);
	}

	@Override
	public void Notification(Optional<Customer> customer) throws MailException {

		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(customer.get().getEmail_id());
		mail.setFrom("prashanthpsn1995@gmail.com");
		mail.setSubject("Coupons and promos");
		mail.setText("Registered Successfully");
		javaMailSender.send(mail);
	}

	@Override
	public Optional<Customer> getCustomer(String email) {

		return repo.findById(email);
	}

}
