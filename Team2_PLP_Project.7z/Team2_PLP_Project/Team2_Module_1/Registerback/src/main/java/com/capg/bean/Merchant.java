package com.capg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Merchant {
	
	
	@Column(name="code")
	private int code=(int)(Math.random()*900000)+1000000;
	
	@Id
	private String email_id;
	@Column(name="merchantName")
	private String merchantName;
	@Column(name="phonenumber")
	private String phoneNumber;
	@Column(name="address")
	private String address;
	@Column(name="producttype")
	private String productType;
	@Column(name="password")
	private String password;
	public Merchant() {
		
	}
	public Merchant(String email_id, String merchantName, String phoneNumber, String address, String productType,
			String password) {
		super();
		this.code=code;
		this.email_id = email_id;
		this.merchantName = merchantName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.productType = productType;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Merchant [email_id=" + email_id + ", merchantName=" + merchantName + ", phoneNumber=" + phoneNumber
				+ ", address=" + address + ", productType=" + productType + ", password=" + password + "]";
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getCode() {
		return code;
	}
	public void setCode() {
		code=(int)Math.random()*9999;
	}
	
}
