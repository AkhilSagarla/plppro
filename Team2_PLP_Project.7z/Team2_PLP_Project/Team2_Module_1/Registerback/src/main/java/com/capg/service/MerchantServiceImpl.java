package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capg.bean.Merchant;
import com.capg.repo.CustomerRepo;
import com.capg.repo.MerchantRepo;

@Service
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	private MerchantRepo repo1;

	@Override
	public void saveMerchant(String email_id, String password,String merchantName, String phoneNumber, String address, String product_type) {
		Merchant m=new Merchant();
		m.setEmail_id(email_id);
		m.setPassword(password);
		m.setMerchantName(merchantName);
		m.setPhoneNumber(phoneNumber);
		m.setAddress(address);
		m.setProductType(product_type);
		repo1.save(m);
		
	}
}
