package com.cg.spring.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.bean.Merchant;

@Repository
public interface IMerchantRepo extends CrudRepository<Merchant, String>{

}
