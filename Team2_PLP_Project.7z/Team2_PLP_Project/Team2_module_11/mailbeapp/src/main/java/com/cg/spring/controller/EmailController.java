package com.cg.spring.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Merchant;
import com.cg.spring.service.ICustomerService;

@RestController
public class EmailController {
	@Autowired
	private ICustomerService service;

	@RequestMapping("/showcustomers")
	public List<Customer> showAllCustomers() {
		return service.showAllCustomers();
	}

	@RequestMapping("/showmerchants")
	public List<Merchant> showAll() {
		return service.showAllMerchants();
	}

	@RequestMapping("/sendcustomer")
	public String sendmailcust(@RequestParam String email) {
		Optional<Customer> customer = service.getCustomer(email);
		try {
			service.NotificationCustomer(customer);
		} catch (MailException e) {
			System.out.println(e.getMessage());
		}
		return "Email sent";
	}

	@RequestMapping("/sendmerchant")
	public String sendmailmer(@RequestParam String email) {
		Optional<Merchant> merchant = service.getMerchant(email);
		try {
			service.NotificationMerchant(merchant);
		} catch (MailException e) {
			System.out.println(e.getMessage());
		}
		return "Email sent";
	}
}
