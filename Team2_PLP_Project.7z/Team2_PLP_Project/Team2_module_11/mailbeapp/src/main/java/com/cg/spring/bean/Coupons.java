package com.cg.spring.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Coupons {

	@Id
	private String coupon;

	private String validity;

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public String getValidity() {
		return validity;
	}

	public void setValidity(String validity) {
		this.validity = validity;
	}

	public Coupons(String coupon, String validity) {
		super();
		this.coupon = coupon;
		this.validity = validity;
	}

	public Coupons() {
		super();
	}

	

}
