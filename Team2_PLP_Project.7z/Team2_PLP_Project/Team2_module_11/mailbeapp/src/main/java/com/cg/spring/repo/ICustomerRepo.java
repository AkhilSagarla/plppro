package com.cg.spring.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.bean.Customer;

@Repository
public interface ICustomerRepo extends CrudRepository<Customer, String>{

}
